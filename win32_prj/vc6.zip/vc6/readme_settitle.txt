DirectReader::convertFromSJISToUTF8(buf2, wm_title_string);
